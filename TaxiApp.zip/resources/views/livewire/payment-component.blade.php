<div>
    <main class="app containerw pb-5">
        <div>
            <p>Order ID: {{ $order_id }}</p>
            <p>Status Code: {{ $status_code }}</p>
            <p>Transaction Status: {{ $transaction_status }}</p>
        </div>
    </main>

</div>