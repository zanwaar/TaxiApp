<?php

namespace App\Http\Livewire\Layanan;

use Livewire\Component;

class Maps extends Component
{
    public function render()
    {
        return view('livewire.layanan.maps');
    }
}
